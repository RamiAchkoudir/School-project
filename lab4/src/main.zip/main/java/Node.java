import java.util.Map;
import java.util.Iterator;

public class Node {

    public int value = 0;
    public Node[] children = new Node[256];

}
